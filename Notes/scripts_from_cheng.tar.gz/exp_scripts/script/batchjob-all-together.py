import os,sys
from time import time,sleep
import datetime

if __name__ == '__main__':
    
    print "all together"
    
    command = "python batchjob161-RUBiS-Original-Local-1dc-2Proxies.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob161-RUBiS-Original-Local-1dc-2Proxies.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob168-RUBiS-Sifter-Local-1dc-2Proxies.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob168-RUBiS-Sifter-Local-1dc-2Proxies.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob162-RUBiS-Original-Local-1dc-1Proxy-Latency.py Deploy"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob162-RUBiS-Original-Local-1dc-1Proxy-Latency.py Config"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob162-RUBiS-Original-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob162-RUBiS-Original-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob162-RUBiS-Original-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob169-RUBiS-Sifter-Local-1dc-1Proxy-Latency.py Deploy"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob169-RUBiS-Sifter-Local-1dc-1Proxy-Latency.py Config"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob169-RUBiS-Sifter-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob169-RUBiS-Sifter-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob169-RUBiS-Sifter-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    
    command = "python batchjob169-RUBiS-Sifter-Local-1dc-1Proxy-Latency.py Run"
    print command, " is runing"
    
    os.system(command)
    print command, "finished"
    sys.exit(-1)
    
   
